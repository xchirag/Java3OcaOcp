package com.fdmgroup.Dao;

public interface SaleItemDao {
	
	

}
