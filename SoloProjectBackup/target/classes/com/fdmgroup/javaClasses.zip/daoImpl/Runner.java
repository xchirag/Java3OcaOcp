package com.fdmgroup.daoImpl;

import java.util.List;

import com.fdmgroup.entity.Customer;

public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CustomerDaoImpl customerDaoImpl = new CustomerDaoImpl();
		
		String userName = "nick7";
		List<Customer> cusomerByName = customerDaoImpl.getCusomerByName(userName);
		System.out.println(cusomerByName.size());
		//System.out.println();
		
		for(Customer customer: cusomerByName){
			System.out.println(customer);
			
		}
		

	}

}

//https://stackoverflow.com/questions/20056847/jpql-the-state-field-path-cannot-be-resolved-to-a-valid-type
