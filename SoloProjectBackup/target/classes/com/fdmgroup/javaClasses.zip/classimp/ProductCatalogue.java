package com.fdmgroup.classimp;

import java.util.List;

import com.fdmgroup.entity.Product;

public class ProductCatalogue {
	
	private int productId;
	private String suppliedBy;
	private int quantityInStock;
	private int deletme;
	
	public boolean isProductInStock(int productId){
		return false;
	}
	
	public void orderProduct(int productId, int quantity, String suppliedBy){
		
	}

	
}
