package com.fdmgroup.controllers;

import org.apache.catalina.connector.Response;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import static org.springframework.web.bind.annotation.RequestMethod.*;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fdmgroup.daoImpl.CustomerDaoImpl;
import com.fdmgroup.daoImpl.ProductDaoImpl;
import com.fdmgroup.daoImpl.SaleItemDaoImpl;
import com.fdmgroup.daoImpl.ShoppingBasketDaoImpl;
import com.fdmgroup.entity.Customer;
import com.fdmgroup.entity.Product;
import com.fdmgroup.entity.SaleItem;
import com.fdmgroup.entity.ShoppingBasket;
import com.fdmgroup.model.User;

@Controller
public class HomeController {

	// private Customer customer;
	// private CustomerDaoImpl customerDaoImpl = new CustomerDaoImpl();

	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("soloprojectjpa1");

	@RequestMapping(value = "listCustomers") // this is link on the page when
												// this is clicked on login page
												// button link
	public String listUsersHandler(Model model) {
		CustomerDaoImpl customerDao = new CustomerDaoImpl();
		List<Customer> listOfCustomers = customerDao.listOfCustomers();
		model.addAttribute("listCustomersToJsp", listOfCustomers);
		return "listTheCustomers";

	}

	@RequestMapping(value = "listShoppingBaskets") // this is name of link when
													// this is called on login
													// page button link
	public String listingShoppingBasketHandler(Model model) {
		ShoppingBasketDaoImpl shoppingBasketDao = new ShoppingBasketDaoImpl();
		// int basketId = 1;
		// ShoppingBasket shoppingBasket =
		// shoppingBasketDao.getShoppingBasket(basketId);
		// this will be done with where clause at the next level

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		/*String string = "select ngs.basketId, ngc.customerName, ngsp.Product_ID, ngp.productName, "
				+ "ngsp.Quantity, ngs.basketPrice, ngs.discountedBasketPrice, ngs.discountedBasketPrice "
				+ "from ng_shoppingbasket_products ngsp join ngsp.ng_shoppingbasket ngs join ngs.NG_CUSTOMER ngc join ngc.ng_product ngp";*/
		
		/*String pString = "select ngs.basketId, ngc.customerName, ngp.id, ngp.productName, ngsp.Quantity, ngs.basketPrice, ngs.discountedBasketPrice, ngs.discountedBasketPrice "
				+ "from ng_shoppingbasket ngs join ng_shoppingbasket_products ngsp on  ngs.basketId = ngsp.basketId "
				+ "join ng_customer ngc on ngc.CustomerNumber = ngs.CustomerNumber join  ng_product ngp on ngsp.Product_ID = ngp.id";*/
		
		String pString = "select ngs.BASKETID, ngc.CUSTOMER_NAME, ngp.PRODUCT_ID, ngp.PRODUCT_NAME, ngsp.Quantity, ngs.basketPrice, ngs.discountedBasketPrice, ngs.discountedBasketPrice "
				+ "from ng_shoppingbasket ngs join ng_shoppingbasket_products ngsp on  ngs.BASKETID = ngsp.NG_SHOPPINGBASKET_BASKETID "
				+ "join ng_customer ngc on ngc.CustomerNumber = ngs.CustomerNumber join  ng_product ngp on ngsp.Product_ID = ngp.PRODUCT_ID";
		
		//List<Object[]> reus = entityManager.createQuery(pString).getResultList();
		
		List<Object[]> reus = entityManager.createNativeQuery(pString).getResultList();
				//entityManager.NativeFieldKeySorterQuery(pString).getResultList();
		
		/*TypedQuery<Customer> sql = entityManager.createQuery(string, Customer.class);
		List<Customer> resultList = sql.getResultList();*/
		
		//basketId
		//https://www.objectdb.com/java/jpa/query/jpql/from#INNER_JOIN_
		
		/*String sqlJoinQuery = "select ngs.BASKETID, ngc.CUSTOMER_NAME, ngsp.PRODUCT_ID, ngp.PRODUCT_NAME, ngsp.QUANTITY, ngs.BASKETPRICE, ngs.DISCOUNTPERCENTAGE, ngs.DISCOUNTEDBASKETPRICE "
				+ "from NG_CUSTOMER ngc, ng_product ngp, ng_shoppingbasket ngs, ng_shoppingbasket_products ngsp "
				+ "where ngc.CUSTOMERNUMBER = ngs.CUSTOMERNUMBER and ngs.BASKETID = ngsp.NG_SHOPPINGBASKET_BASKETID and ngsp.product_id = ngp.PRODUCT_ID";

		// String joinQuery="select ngs.BASKETID, ngc.CUSTOMER_NAME,
		// ngsp.PRODUCT_ID, ngp.PRODUCT_NAME, ngsp.QUANTITY, ngs.BASKETPRICE,
		// ngs.DISCOUNTPERCENTAGE, ngs.DISCOUNTEDBASKETPRICE from
		// ng_shoppingbasket_products ngsp inner join ng_shoppingbasket ngs on
		// ngs.BASKETID = ngsp.NG_SHOPPINGBASKET_BASKETID inner join NG_CUSTOMER
		// ngc on ngc.CUSTOMERNUMBER = ngs.CUSTOMERNUMBER inner join ng_product
		// ngp on ngsp.product_id = ngp.PRODUCT_ID";
		// Query nativeQuery = entityManager.createNativeQuery(joinQuery);
		Query nativeQuery = entityManager.createNativeQuery(sqlJoinQuery);
		// List<Object[]> listOfBaskets = nativeQuery.getResultList();

		// List<ShoppingBasket> listOfBaskets =
		// shoppingBasketDao.listOfBaskets();

		List<Object> listOfBaskets = nativeQuery.getResultList();*/
		model.addAttribute("listBasketsToJsp", reus);
		return "listingShoppingBasket";
	}

	@RequestMapping(value = "listProducts")
	public String listProductsHandler(Model model) {

		// EntityManager entityManager =
		// entityManagerFactory.createEntityManager();
		ProductDaoImpl productDao = new ProductDaoImpl();
		List<Product> listOfProducts = productDao.listOfProducts();
		model.addAttribute("listProductsToJsp", listOfProducts);
		return "listTheProducts";
	}

	@RequestMapping(value = "listItems") // link on the page must be called
											// this!
	public String listTheItemsHandler(Model model) {

		EntityManager entityManager = entityManagerFactory.createEntityManager(); // logic
																					// in
																					// controller
		SaleItemDaoImpl saleItemDao = new SaleItemDaoImpl(entityManager);
		List<SaleItem> listOfItems = saleItemDao.listTheItems();

		model.addAttribute("listAttribute", listOfItems);
		// we are forwarding listOfItems which came in from daoImpl to jsp
		// webpage as 'listAttribute'
		// model.addAttribute adding attribute/variable to jsp webpage as
		// 'listAttribute'

		return "listTheItems"; // this will return listTheItems.jsp page when
								// user click on link stating listItems (which
								// is provided in value).
	}

	@RequestMapping(value = "/")
	public String loginPageController(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}

	@RequestMapping(value = "submitLogin", method = POST) // form method action // name must be 'submitLogin'
	public String loginSubmitHandler(Model model, User user, HttpServletRequest request) {
		model.addAttribute("user", user); // taking information from the page // submitted

		//request.setAttribute(arg0, arg1);
		String username = user.getUserName();
		String password = user.getPassword();
		boolean validCustomer = false;

		// return "login";

		CustomerDaoImpl customerDaoImpl = new CustomerDaoImpl();

				
		List<Customer> custListFromDb = customerDaoImpl.getCusomerByName(username);
		
		for(Customer customer: custListFromDb){
			
			//System.out.println(customer);
			if(customer.getUserName().equals(username) && customer.getPassword().equals(password)){
				validCustomer = true;
			}
		}

		if(validCustomer)
			return "welcome";
		else{
			request.setAttribute("error", "User name and/or password is not correct.");
			request.setAttribute("error1", "Please try again or Register.");
			return "login";
		}
		
	

	}

	@RequestMapping(value = "registration")
	public String registrationHandler(Model model) {
		model.addAttribute("user", new User());
		return "registration";
	}

	@RequestMapping(value = "submitRegistration", method = POST)
	public String registrationSubmitHandler(Model model, User user, HttpServletRequest request) {

		/*if (user.getFirstName().length() == 0 || user.getLastName().length() == 0
				|| user.getEmailAddress().length() == 0 || user.getPassword().length() == 0
				|| user.getUserName().length() == 0 || user.getConfirmPassword().length() == 0) {
			request.setAttribute("error", "Any one of inputted item is zero length or email address is not valid");
			return "registration";
		}*/
		
		if (user.getFirstName().length() == 0){
			request.setAttribute("error1", "First name is a required field and cannot be empty");
			return "registration";
		}
		
		if (user.getLastName().length() == 0){
			request.setAttribute("error2", "Last name is a required field and cannot be empty");
			return "registration";
		}
			
		if (user.getUserName().length() == 0)
		{
			request.setAttribute("error3", "User name is a required field and cannot be empty");
			return "registration";
		}
		
		if (user.getPassword().length() == 0)
		{
			request.setAttribute("error4", "Password is a required field and cannot be empty");
			return "registration";
		}
		
		if (user.getConfirmPassword().length() == 0)
		{
			request.setAttribute("error5", "Confirm Password is a required field and cannot be empty");
			return "registration";
		}
		
		if (user.getHomeAddress().length() == 0)
		{
			request.setAttribute("error6", "Home address is a required field and cannot be empty");
			return "registration";
		}
		
		if (user.getEmailAddress().length() == 0)
		{
			request.setAttribute("error7", "Email is a required field and cannot be empty");
			return "registration";
		}
		
		if (!user.getPassword().equals(user.getConfirmPassword())){
			request.setAttribute("error", "Password and Confirm Password should be same and cannot be empty");
			return "registration";
		}
		
		/*this.customerNumber = customerNumber;
		this.customerName = customerName;
		this.password = password;
		this.address = address;
		this.email = email;
		this.shipAddress = shipAddress;
		this.userName = userName;*/
		
		CustomerDaoImpl customerDaoImpl = new CustomerDaoImpl();
		List<Customer> cusomerByName = customerDaoImpl.getCusomerByName(user.getUserName());
		if (cusomerByName.size() == 0){
			Customer temp = new Customer();
			temp.setCustomerName(user.getFirstName());
			temp.setUserName(user.getUserName());
			temp.setCustomerNumber(new Random().nextInt(1000));
			
			//temp.setCustomerNumber(customerNumber);
			temp.setPassword(user.getPassword());
			temp.setAddress(user.getHomeAddress());
			temp.setShipAddress(user.getHomeAddress());
			
			temp.setEmail(user.getEmailAddress());
			
			customerDaoImpl.addCustomer(temp);
			return "login";
		}
		else{
			request.setAttribute("error", "If you are already registered then please login");
			return "registration";
		}
	}

}

/*
 * useful notes
 * 
 * // UsersDao userDao = new UsersDao(); // User tempuser =
 * userDao.getUSer(username); // // // not a good practice to because if first
 * past is not null then second part will never be executed // // therefore
 * avoid // if(user != null && tempuser.getPassword().equals(password)){ //
 * return "loginsuccess"; // } // else // return "login";
 * 
 * //return "loginsuccess"; // must be the name of jsp page with case
 * sensitivity
 */

// firstly created an object to get the model sorted
// then created a daoImpl to get the methods sorted
// put and manage controller (get the items from database first into controller
// ==> then pass the list to jsp page ===> display list on jsp using tag)
// sort out jsp page


//code of registration comments

// make the user object to covert over from customer object
// return "registration";

// Customer customerNew = new Customer();
// user.getFirstName() = customer

// CustomerDaoImpl customerNew = new CustomerDaoImpl();
// Customer custTemp = new Customer();
// custTemp =
// customerNew.addCustomer(user);
// if (username.length() == 0 || password.length() == 0)



// code of login handler

// //		List<Customer> listOfCustomers = customerFromDatabase.listOfCustomers();
//
//for (Customer customer : listOfCustomers) {
//	if (customer.getCustomerName().equals(username) && customer.getPassword().equals(password)) {
//		validCustomer = true; // welcome page to be created
//	}
//}


// code from handlener commented

// customerFromDatabase.getCustomer(CustomerNumber);

/*
 * List<Customer> listOfCustomers = customerDaoImpl.listOfCustomers();
 * // make an iterator and see whether we can get data in that way or
 * not
 * 
 * ListIterator<Customer> iterateOver = listOfCustomers.listIterator();
 * 
 * while(iterateOver.hasNext()){ customer = iterateOver.next();
 * System.out.println(customer); }
 */

// int customerId = customer.getCustomerNumber();
// String customerName = customer.getCustomerName();
//
// System.out.println(customerId + " + " + customerName);